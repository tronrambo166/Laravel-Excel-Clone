<footer class="footer">
  <span class="text-right">
   
  </span>
  <span class="float-right">
   
  </span>
</footer>
