<?php $__env->startSection('content'); ?>
  <div class="row">
   <h3 class="text-center" > See all products </h3>

<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
Name: <?php echo e($p->name); ?>


Image: <img width="100px" src="images/<?php echo e($p->image); ?>">

<div> ---------------------------------------------------------------------- </div> <br>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  $(document).ready(function() {
    $('#table').DataTable();
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/see_products.blade.php ENDPATH**/ ?>