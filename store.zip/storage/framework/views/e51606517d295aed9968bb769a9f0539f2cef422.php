<?php $__env->startSection('content'); ?>
  <div class="row">
    
<h3 style="display: block; margin-right: 100px;" class="text-center" > Add a product </h3> <br> <br>


<form action="<?php echo e(route('add_product')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?>

Product name: <input required="" type="text" name="product_name" placeholder="enter product name"> <br><br>

Image: <input required="" type="file" name="image" > <br><br>

<button type="submit" class="btn btn-success "  >  add</button>


</form>


  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  $(document).ready(function() {
    $('#table').DataTable();
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/add_product.blade.php ENDPATH**/ ?>