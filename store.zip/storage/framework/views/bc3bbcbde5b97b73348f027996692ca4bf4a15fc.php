

<?php $__env->startSection('content'); ?>


<div class="container-fluid">
	
	<div class="row">
	<div class="col-lg-12">
			<button class="btn btn-success float-right btn-sm" id="new_user"></button>
	</div>
	</div>
	<br>
	<div class="row">
		<div class="card col-lg-12">
			<div class="card-body">
				<table class="table-striped table-bordered w-100">
			<thead>
				<tr>
					<th class="text-center">#</th>
					<th class="text-center">Name</th>
					<th class="text-center">Email</th>
					<th class="text-center">Type</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tbody class="w-100">
				
				 <tr>
				 	<td class="text-center">
				 		<?php echo e($u->id); ?>

				 	</td>
				 	<td>
				 		<?php echo e($u->name); ?>

				 	</td>
				 	
				 	<td>
				 		<?php echo e($u->email); ?>

				 	</td>
				 	<td>
				 		<?php echo e($u->type); ?>

				 	</td>
			
				 </tr>
				
			</tbody>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</table>
			</div>
		</div>
	</div>

<h3 class=" my-4 mr-5 text-center">Add User </h3>


<div class="container w-50 m-auto">
	<form method="POST" action="<?php echo e(route('adduser')); ?>">
                        <?php echo csrf_field(); ?>

<div class="form-group "><label class="d-inline small text-dark mb-1" for="inputEmailAddress">Name</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="name" name="name" placeholder="" id="inputEmailAddress" 
                                            value="" autocomplete="email" autofocus  /></div>                                                                                                 
                                            <div class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-group"><label class=" ml-4 d-inline text-dark small mb-1" for="inputPassword">Email</label> 
                                            
                                            <input class=" d-inline w-50 form-control ml-4 my-2 px-2" name="email" id="inputPassword" type="email" placeholder=""
                                            value=""            /></div>

                                            <div class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-group"><label class=" d-inline text-dark small mb-1" for="inputPassword">Password</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-4 my-2 px-2" name="password" id="inputPassword" type="password" placeholder=""
                                            value=""            /></div>

                                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  
                                            <div class="form-group d-flex align-items-center justify-content-between mt-5 mb-0">
                                            <?php if(Route::has('forgetPass')): ?> 
                                            <a href="<?php echo e(route('password.request')); ?>" class="text">Forgot password ?</a> <?php endif; ?>
                                            
                                            <input style="margin-left: 100px;background: aliceblue;border-radius: 20px; " type="submit"class=" w-25 btn btn-info text-dark d-block font-weight-bold " href="" name="add" value="Add" /></div>
                    </form>

                </div>



</div>
<script>
	$('table').dataTable();
$('#new_user').click(function(){
	uni_modal('New User','manage_user.php')
})
$('.edit_user').click(function(){
	uni_modal('Edit User','manage_user.php?id='+$(this).attr('data-id'))
})
$('.delete_user').click(function(){
		_conf("Are you sure to delete this user?","delete_user",[$(this).attr('data-id')])
	})
	function delete_user($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_user',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\gym\resources\views/pages/users.blade.php ENDPATH**/ ?>