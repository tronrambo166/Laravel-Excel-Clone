
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Store </title>
  <meta name="description" content="Demo | Demo Admin">
  <meta name="author" content="Demo Web Development - https://domain">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.css">

 <!-- include('layouts.partials.styles') -->
<style>
.show {
  z-index: 1000;
  position: absolute;
  background-color: #C0C0C0;
  border: 1px solid blue;
  padding: 2px;
  display: block;
  margin: 0;
  list-style-type: none;
  list-style: none;
}

.hide {
  display: none;
}

.show li {
  list-style: none;
}

.show a {
  border: 0 !important;
  text-decoration: none;
}

.show a:hover {
  text-decoration: underline !important;
}

td {border: 1px #DDD solid; padding: 5px; }

.selected {
    background-color: brown;
    color: #FFF;
}

div {
  resize: horizontal;
  overflow: auto;
  ;
}

td {
  text-align: center;
}

 </style>

</head>

<body class="adminbody">

  <div>
    <div>
      <div>

        <div id="banner-message">
  <table cellpadding="0" cellspacing="0" border="0">
    <thead>
      <tr>
        <th>
          <div>One</div>
        </th>
        <th>
          <div>Two</div>
        </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>ab</td>
        <td>cd</td>
      </tr>
    </tbody>
  </table>

</div>
</div>
        <!-- END container-fluid -->

      </div>
      <!-- END content -->

    </div>
    <!-- END content-page -->

 

  
  <!-- END main -->

 


<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
       
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script type="text/javascript" charset="utf8" src="ColReorderWithResize.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.js"></script>

<script type="text/javascript">
$("#thead_DispatchTrip th").resizable({
        handles: "e",
        resize: function (event, ui) {
            $(ui.element).find('div').width(ui.size.width);
        }
    });

tableWidth = [];
    $("#thead_DispatchTrip th").each(function () {
        tableWidth.push($(this).find('div').width());
    });

    $("#thead_DispatchTrip th").each(function (i,el) {
    $(this).find('div').width(tableWidth[i]);
});

  </script>

	
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_projects\store\resources\views/data2.blade.php ENDPATH**/ ?>