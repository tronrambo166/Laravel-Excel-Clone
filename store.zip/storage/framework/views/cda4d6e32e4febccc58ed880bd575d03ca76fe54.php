


<?php if(Session::get('user_id')==''): ?>)
<?php
 header("Location: " . URL::to('/'), true, 302);
        exit(); ?>
   
<?php else: ?> 

<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Agramonia | Admin</title>
  <meta name="description" content="Demo | Demo Admin">
  <meta name="author" content="Demo Web Development - https://domain">

  <?php echo $__env->make('layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="adminbody">

  <div id="main">

    <!-- top bar navigation -->
    <?php echo $__env->make('layouts.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Navigation -->


    <!-- Left Sidebar -->
      <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Sidebar -->


    <div class="content-page">

      <!-- Start content -->
      <div class="content">

        <div class="container-fluid">

          <?php $__env->startSection('content'); ?>
          <?php echo $__env->yieldSection(); ?>


        </div>
        <!-- END container-fluid -->

      </div>
      <!-- END content -->

    </div>
    <!-- END content-page -->

  <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </div>
  <!-- END main -->

  <?php echo $__env->make('layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel_projects\gym\resources\views/layouts/master.blade.php ENDPATH**/ ?>