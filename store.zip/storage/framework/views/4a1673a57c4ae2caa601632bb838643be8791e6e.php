 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
 <div class="left main-sidebar">

  <div class="sidebar-inner leftscroll">

    <div id="sidebar-menu" class=" show">

      <ul class=" show">

        

						
				
        <li class="submenu open">
          <a href="#" class=""><i class="fa fa-fw fa-bars"></i> <span> <?php echo e("Menu"); ?> </span> <span class="menu-arrow"></span></a>
          <ul class="list-unstyled">
          	<li><a href="" class=""><?php echo e('Home'); ?></a></li>
            <li><a href="" class=""><?php echo e('Add Member'); ?> </a></li>
            <li><a href="" class=""><?php echo e('Members'); ?></a></li>
            <li><a href="" class=""><?php echo e('Plans/Packages'); ?></a></li>
            <li><a href="" class=""><?php echo e('Trainers'); ?></a></li>
            <li><a href="" class=""><?php echo e('Users'); ?></a></li>
          </ul>
        </li>
       

      </ul>

      <div class="clearfix"></div>

    </div>

    <div class="clearfix"></div>

  </div>

</div>

<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
       
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<?php /**PATH C:\xampp\htdocs\laravel_projects\store\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>