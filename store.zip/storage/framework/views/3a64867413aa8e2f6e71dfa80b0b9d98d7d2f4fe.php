
<!DOCTYPE HTML>
<html lang="en-US">
<head>
  <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Bubble and Dots</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
  <link rel="stylesheet" href="style.css">
</head>

<body> 

<form action="<?php echo e(route('adminLogin')); ?>" method="post" class="form-control"> <?php echo csrf_field(); ?>

Email: <input required="" type="text" name="email" placeholder="enter your email"> <br><br>

Password: <input required="" type="text" name="password" placeholder="enter your password"> <br>

<button type="submit" class="btn btn-success "  >  Log In</button>


</form>


   </body> 


<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
       
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script><?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/login.blade.php ENDPATH**/ ?>