<?php $__env->startSection('content'); ?>
  <div class="row">
    
<h3 style="display: block; margin-right: 100px;" class="text-center" > Add a member </h3> <br> <br>





<div class="container w-50 m-auto">
  <form method="POST" action="<?php echo e(route('add_members')); ?>">
                        <?php echo csrf_field(); ?>

<div class="form-group ">

  <label class="d-inline small text-dark mb-1 ml-1" for="inputEmailAddress">Name</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="name" name="name" id="inputEmailAddress" 
                                           autocomplete="email" autofocus  /></div>   

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">member_id</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-4 px-2 my-2" type="number" name="member_id" id="inputEmailAddress" 
                                             autocomplete="email" autofocus  /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">plan_id</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="number" name="plan_id"  id="inputEmailAddress" 
                                           autocomplete="email" autofocus  /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Address</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="text" name="address"  id="inputEmailAddress" 
                                            autocomplete="email" autofocus  /></div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Gender</label>
                                            
                                           <select class="ml-5" name="gender">
                                             <option value="male">Male</option>
                                             <option value="female">Female</option>

                                           </select>
                                           </div>    

                                            <div class="form-group ">

  <label class="d-inline small text-dark mb-1" for="inputEmailAddress">Contact</label>
                                            
                                            <input class=" d-inline w-50 form-control ml-5 px-2 my-2" type="number" name="contact"  id="inputEmailAddress" 
                                            autocomplete="email" autofocus  /></div>                                                                                                  


                                            <div class=" <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-group"><label class=" ml-2 d-inline text-dark small mb-1" for="inputPassword">Email</label> 
                                            
                                            <input class=" ml-5 d-inline w-50 form-control ml-4 my-2 px-2" name="email" id="inputPassword" type="email" placeholder="Enter Email"
                                            value=""            /></div>

                                          

                                          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  
                                            <div class="form-group d-flex align-items-center justify-content-between mt-5 mb-0">
                                            <?php if(Route::has('forgetPass')): ?> 
                                            <a href="<?php echo e(route('password.request')); ?>" class="text">Forgot password ?</a> <?php endif; ?>
                                            
                                            <input style="margin-left: 100px;background: aliceblue;border-radius: 20px; " type="submit"class=" w-25 btn btn-info text-dark d-block font-weight-bold " href="" name="add" value="Add" /></div>
                    </form>

                </div>



  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script>
  $(document).ready(function() {
    $('#table').DataTable();
  } );
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_projects\store\resources\views/pages/add_members.blade.php ENDPATH**/ ?>