<footer class="footer">
  <span class="text-right">
   
  </span>
  <span class="float-right">
   
  </span>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel_projects\store\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>