<footer class="footer">
  <span class="text-right">
    <?php echo e(__('admin.copyright')); ?> <a target="_blank" href="http://agramonia.com">Agramonia</a>
  </span>
  <span class="float-right">
    <?php echo e(__('admin.powered_by')); ?> <a target="_blank" href="http://work-fort.net"><b>WorkFort</b></a>
  </span>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel_projects\agramonia\resources\views/admin/layouts/partials/footer.blade.php ENDPATH**/ ?>